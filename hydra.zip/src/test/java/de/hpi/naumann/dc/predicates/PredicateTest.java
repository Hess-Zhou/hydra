package de.hpi.naumann.dc.predicates;

public class PredicateTest {

}
