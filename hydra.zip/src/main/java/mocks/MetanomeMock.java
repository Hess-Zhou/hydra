package mocks;

import de.hpi.naumann.dc.input.Input;
import de.metanome.algorithm_integration.AlgorithmConfigurationException;
import de.metanome.algorithm_integration.AlgorithmExecutionException;
import de.metanome.algorithm_integration.ColumnIdentifier;
import de.metanome.algorithm_integration.configuration.ConfigurationSettingFileInput;
import de.metanome.algorithm_integration.input.InputGenerationException;
import de.metanome.algorithm_integration.input.RelationalInput;
import de.metanome.algorithm_integration.input.RelationalInputGenerator;
import de.metanome.algorithm_integration.result_receiver.DenialConstraintResultReceiver;
import de.metanome.algorithm_integration.results.DenialConstraint;
import de.metanome.algorithm_integration.results.OrderDependency;
import de.metanome.algorithm_integration.results.Result;
import de.hpi.naumann.dc.algorithms.hybrid.HydraMetanome;
import de.metanome.backend.input.file.DefaultFileInputGenerator;
import de.metanome.backend.result_receiver.ResultCache;
import utils.FileUtils;
import config.Config;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MetanomeMock {

    public static void execute(Config conf) {
        try {
            ConfigurationSettingFileInput input = new ConfigurationSettingFileInput(
                    conf.inputFolderPath + conf.inputDatasetName + conf.inputFileEnding, true,
                    conf.inputFileSeparator, conf.inputFileQuotechar, conf.inputFileEscape, conf.inputFileStrictQuotes,
                    conf.inputFileIgnoreLeadingWhiteSpace, conf.inputFileSkipLines, conf.inputFileHasHeader,
                    conf.inputFileSkipDifferingLines, conf.inputFileNullString);
            System.out.println(input.getFileName());
            RelationalInputGenerator inputGenerator = new DefaultFileInputGenerator(input);
            List<ColumnIdentifier> acceptColumns = getAcceptedColumns(inputGenerator);
            //System.out.println(acceptColumns);
            ResultCache resultReceiver = new ResultCache("MetanomeMock", acceptColumns);
            //List<ResultCache> resultCacheList = new ArrayList<>();
            HydraMetanome algorithm = new HydraMetanome();
            algorithm.setRelationalInputConfigurationValue(HydraMetanome.INPUT, inputGenerator);
            //algorithm.setStringConfigurationValue(HydraMetanome.EFFICIENCY_THRESHOLD, conf.someStringParameter);
            //algorithm.setIntegerConfigurationValue(HydraMetanome.SAMPLE_ROUNDS, conf.someIntegerParameter);
            //algorithm.setBooleanConfigurationValue(HydraMetanome.NO_CROSS_COLUMN, conf.someBooleanParameter);
            algorithm.setResultReceiver(resultReceiver);
            //algorithm.setResultReceiverList(resultCacheList);

            long runtime = System.currentTimeMillis();
            algorithm.execute();

//            List<Input> inputList = algorithm.getInputList();
//            System.out.println("total itemSet: " + inputList.size());
//            int cores = Runtime.getRuntime().availableProcessors();
//            System.out.println("cpu cores: " + cores);
//            ExecutorService exec = Executors.newSingleThreadExecutor();
//
//            for (Input temp : inputList) {
//                algorithm.setSingleInput(temp);
//                exec.execute(algorithm);
//            }
            runtime = System.currentTimeMillis() - runtime;
            writeResults(conf, resultReceiver, algorithm, runtime);
            //exec.shutdown();
        } catch (AlgorithmExecutionException | IOException e) {
            e.printStackTrace();
        }
    }

    private static List<ColumnIdentifier> getAcceptedColumns(RelationalInputGenerator relationalInputGenerator) throws InputGenerationException, AlgorithmConfigurationException {
        List<ColumnIdentifier> acceptedColumns = new ArrayList<>();
        RelationalInput relationalInput = relationalInputGenerator.generateNewCopy();
        String tableName = relationalInput.relationName();
        for (String columnName : relationalInput.columnNames())
            acceptedColumns.add(new ColumnIdentifier(tableName, columnName));
        return acceptedColumns;
    }

    private static void writeResults(Config conf, ResultCache resultReceiver, Object algorithm, long runtime) throws IOException {
        if (conf.writeResults) {
            String outputPath = conf.measurementsFolderPath + conf.inputDatasetName + "_" + algorithm.getClass().getSimpleName() + File.separator;
            List<Result> results = resultReceiver.fetchNewResults();

            FileUtils.writeToFile(
                    algorithm.toString() + "\r\n\r\n" + conf.toString() + "\r\n\r\n" + "Runtime: " + runtime + "\r\n\r\n" + "Results: " + results.size(),
                    outputPath + conf.statisticsFileName);
            FileUtils.writeToFile(format(results), outputPath + conf.resultFileName);
        }
    }

//    private static void writeResults(Config conf, List<ResultCache> resultReceiverList, Object algorithm, long runtime) throws IOException {
//        if (conf.writeResults) {
//            String outputPath = conf.measurementsFolderPath + conf.inputDatasetName + "_" + algorithm.getClass().getSimpleName() + File.separator;
//            for(ResultCache resultReceiver:resultReceiverList){
//
//            }
//            List<Result> results = resultReceiver.fetchNewResults();
//
//            FileUtils.writeToFile(
//                    algorithm.toString() + "\r\n\r\n" + conf.toString() + "\r\n\r\n" + "Runtime: " + runtime + "\r\n\r\n" + "Results: " + results.size(),
//                    outputPath + conf.statisticsFileName);
//            FileUtils.writeToFile(format(results), outputPath + conf.resultFileName);
//        }
//    }

    private static String format(List<Result> results) {
        StringBuilder builder = new StringBuilder();
        for (Result result : results) {
            DenialConstraint dc = (DenialConstraint) result;
            //OrderDependency od = (OrderDependency) result;
            builder.append(dc.toString() + "\r\n");
        }
        return builder.toString();
    }
}
