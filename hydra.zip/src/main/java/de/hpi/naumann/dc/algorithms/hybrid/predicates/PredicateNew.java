package de.hpi.naumann.dc.algorithms.hybrid.predicates;

import java.util.Arrays;
import java.util.Collection;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import de.metanome.algorithm_integration.ColumnIdentifier;
import de.metanome.algorithm_integration.Operator;
import de.metanome.algorithm_integration.Predicate;

import java.util.*;

public class PredicateNew implements Predicate {

    private ColumnIdentifier column1;
    private int index1;

    private Operator op;

    private ColumnIdentifier column2;
    private int index2;
    private String value1;
    private String value2;


    @JsonCreator
    public PredicateNew(@JsonProperty("column1") ColumnIdentifier column1,
                        @JsonProperty("index1") int index1, @JsonProperty("op") Operator op,
                        @JsonProperty("column2") ColumnIdentifier column2, @JsonProperty("index2") int index2,
                        String value1, String value2) {
        super();
        this.column1 = column1;
        this.index1 = index1;
        this.op = op;
        this.column2 = column2;
        this.index2 = index2;
        this.value1 = value1;
        this.value2 = value2;
    }

    public ColumnIdentifier getColumn1() {
        return column1;
    }

    public int getIndex1() {
        return index1;
    }

    public Operator getOp() {
        return op;
    }

    public ColumnIdentifier getColumn2() {
        return column2;
    }

    public int getIndex2() {
        return index2;
    }

    @Override
    public Collection<ColumnIdentifier> getColumnIdentifiers() {
        return Arrays.asList(column1, column2);
    }

    @Override
    public String toString() {
        return "t" + index1 + "." + column1 + "= '" + value1 + "' " + op.getShortString() + "t" + index2 + "." + column2 + "= '" + value2 + "' ";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((column1 == null) ? 0 : column1.hashCode());
        result = prime * result + ((column2 == null) ? 0 : column2.hashCode());
        result = prime * result + index1;
        result = prime * result + index2;
        result = prime * result + ((op == null) ? 0 : op.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PredicateNew other = (PredicateNew) obj;
        if (column1 == null) {
            if (other.column1 != null)
                return false;
        } else if (!column1.equals(other.column1))
            return false;
        if (column2 == null) {
            if (other.column2 != null)
                return false;
        } else if (!column2.equals(other.column2))
            return false;
        if (index1 != other.index1)
            return false;
        if (index2 != other.index2)
            return false;
        if (op != other.op)
            return false;
        return true;
    }
}
