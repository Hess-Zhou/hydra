package de.hpi.naumann.dc.input;

import java.util.*;
import java.util.stream.Collectors;

import de.hpi.naumann.dc.fpgrowth.FPTreeForCSV;
import de.hpi.naumann.dc.fpgrowth.TreeNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.hpi.naumann.dc.helpers.IndexProvider;
import de.metanome.algorithm_integration.input.InputIterationException;
import de.metanome.algorithm_integration.input.RelationalInput;

public class Input {
    private int lineCount = 0;
    private List<ParsedColumn<?>> parsedColumns = new ArrayList<>();
    private String name = "";
    private Column[] columns;
    public List<Integer> categoryName = new ArrayList<>();
    public HashMap<Integer, List<String>> categoryMap = new HashMap<>();
    public List<List<String>> pattenTuples = new ArrayList<>();

    public Input(RelationalInput relationalInput, int rowLimit) throws InputIterationException {
        final int columnCount = relationalInput.numberOfColumns();
        this.columns = new Column[columnCount];
        for (int i = 0; i < columnCount; ++i) {
            columns[i] = new Column(relationalInput.relationName(), relationalInput.columnNames().get(i));
        }

        int lineCount = 0;
        while (relationalInput.hasNext()) {
            List<String> line = relationalInput.next();
            for (int i = 0; i < columnCount; ++i) {
                columns[i].addLine(line.get(i));
            }
            ++lineCount;
            if (rowLimit > 0 && lineCount >= rowLimit)
                break;
        }
        this.lineCount = lineCount;

        this.parsedColumns = new ArrayList<>(columns.length);
        //createCategory(0.1,20);
        //createParsedColumns();
        //System.out.println(this.categoryName);
        this.name = relationalInput.relationName();
        System.out.println("tableName: " + this.name + " (" + this.lineCount + ", " + columnCount + ")");
    }

    public void constructFP(RelationalInput relationalInput, double k, int num) throws InputIterationException {
        createCategroy(num);
        //System.out.println("111  "+this.categoryName);
        FPTreeForCSV fptree = new FPTreeForCSV();
        List<List<String>> transRecords = fptree.readTransData(relationalInput, this.categoryName);
        fptree.setMinSup((int) (transRecords.size() * k));
        long startTime = System.currentTimeMillis();
        ArrayList<TreeNode> F1 = fptree.buildF1Items(transRecords);
        //fptree.printF1(F1);
        TreeNode treeroot = fptree.buildFPTree(transRecords, F1);
        //fptree.printFPTree(treeroot);
        Map<List<String>, Integer> patterns = fptree.findFP(treeroot, F1);
        System.out.println("size of F1 = " + F1.size());
        long endTime = System.currentTimeMillis();
        System.out.println("共用时：" + (endTime - startTime) + "ms");
        this.pattenTuples = fptree.printFreqPatterns(patterns, F1);
        //System.out.println(fptree.categoryList);
        this.categoryName = new ArrayList<>(fptree.categoryList);
    }

    private List<Integer> createIndex(List<String> valueList) {
        List<Integer> indexList = new ArrayList<>();
        for (int i = 0; i < this.lineCount; ++i) {
            int j = 0;
            for (; j < this.columns.length; ++j) {
                if (valueList.get(j).equals("-")) continue;
                if (!this.columns[j].getString(i).equals(valueList.get(j))) break;
            }
            if (this.columns.length == j) indexList.add(i);
        }
        return indexList;
    }

    private Input createSubParsedColumns(List<Integer> indexList, List<String> valueList) throws InputIterationException {
        int i = 0;
        List<ParsedColumn<?>> subParsedColumns = new ArrayList<>();
        for (Column c : this.columns) {
            switch (c.getType()) {
                case LONG: {
                    ParsedColumn<Long> parsedColumn = new ParsedColumn<Long>(this.name, c.getName(), Long.class, i, this.categoryName.contains(i), valueList.get(i));
                    for (int l : indexList) {
                        parsedColumn.addLine(c.getLong(l));
                    }
                    subParsedColumns.add(parsedColumn);
                }
                break;
                case NUMERIC: {
                    ParsedColumn<Double> parsedColumn = new ParsedColumn<Double>(this.name, c.getName(), Double.class, i, this.categoryName.contains(i), valueList.get(i));
                    for (int l : indexList) {
                        parsedColumn.addLine(c.getDouble(l));
                    }
                    subParsedColumns.add(parsedColumn);
                }
                break;
                case STRING: {
                    ParsedColumn<String> parsedColumn = new ParsedColumn<String>(this.name, c.getName(), String.class, i, this.categoryName.contains(i), valueList.get(i));
                    for (int l : indexList) {
                        parsedColumn.addLine(c.getString(l));
                    }
                    subParsedColumns.add(parsedColumn);
                }
                break;
                default:
                    break;
            }
            ++i;
        }
        Input temp = new Input(indexList.size(), subParsedColumns, this.name);
        return temp;
    }


    private void createParsedColumns() {
        int i = 0;
        for (Column c : this.columns) {
            switch (c.getType()) {
                case LONG: {
                    ParsedColumn<Long> parsedColumn = new ParsedColumn<Long>(this.name, c.getName(), Long.class, i, this.categoryName.contains(i));
                    for (int l = 0; l < lineCount; ++l) {
                        parsedColumn.addLine(c.getLong(l));
                    }
                    parsedColumns.add(parsedColumn);
                }
                break;
                case NUMERIC: {
                    ParsedColumn<Double> parsedColumn = new ParsedColumn<Double>(this.name, c.getName(), Double.class, i, this.categoryName.contains(i));
                    for (int l = 0; l < lineCount; ++l) {
                        parsedColumn.addLine(c.getDouble(l));
                    }
                    parsedColumns.add(parsedColumn);
                }
                break;
                case STRING: {
                    ParsedColumn<String> parsedColumn = new ParsedColumn<String>(this.name, c.getName(), String.class, i, this.categoryName.contains(i));
                    for (int l = 0; l < lineCount; ++l) {
                        parsedColumn.addLine(c.getString(l));
                    }
                    parsedColumns.add(parsedColumn);
                }
                break;
                default:
                    break;
            }
            ++i;
        }
    }

    public int getLineCount() {
        return lineCount;
    }

    public ParsedColumn<?>[] getColumns() {
        return parsedColumns.toArray(new ParsedColumn[0]);
    }

    public String getName() {
        return name;
    }

    public Input(RelationalInput relationalInput) throws InputIterationException {
        this(relationalInput, -1);
    }

    public Input(int line, List<ParsedColumn<?>> pcList, String tableName) throws InputIterationException {
        this.lineCount = line;
        this.parsedColumns = pcList;
        this.name = tableName;
    }

    public void createCategroy(int num) {
        int i = 0;
        for (Column c : this.columns) {
            if (c.getUnique() <= num) {
                this.categoryName.add(i);
            }
            i++;
        }
    }

    public void createCategory(double k, int num) {
        int i = 0;
        for (Column c : this.columns) {
            //System.out.println(c.getUnique());
            if (c.getUnique() <= num) {
                HashSet<String> columsUnique = c.getValueSet();
                List<String> categoryValues = new ArrayList<>();
                boolean isFull = false;
                for (String value : columsUnique) {
                    int count = c.getFrequency(value);
                    //System.out.println((double) count / this.lineCount);
                    if ((double) count / this.lineCount >= k) {
                        if ((double) count / this.lineCount >= 1 - k) isFull = true;
                        categoryValues.add(value);
                    }
                }
                if (!categoryValues.isEmpty()) {
                    // add "-" means every values
                    if (!isFull) categoryValues.add("-");
                    this.categoryName.add(i);
                    this.categoryMap.put(i, categoryValues);
                }
            }
            i++;
        }
    }

    private static <T> void descartesRecursive(List<List<T>> originalList, int position, List<List<T>> returnList, List<T> cacheList) {
        List<T> originalItemList = originalList.get(position);
        for (int i = 0; i < originalItemList.size(); i++) {
            //最后一个复用cacheList，节省内存
            List<T> childCacheList = (i == originalItemList.size() - 1) ? cacheList : new ArrayList<>(cacheList);
            childCacheList.add(originalItemList.get(i));
            if (position == originalList.size() - 1) {//遍历到最后退出递归
                returnList.add(childCacheList);
                continue;
            }
            descartesRecursive(originalList, position + 1, returnList, childCacheList);
        }
    }

    //discartes
    public List<Input> getInput(double k, int num) throws InputIterationException {
        List<Input> inputList = new ArrayList<>();
        createCategory(k, num);
        List<List<String>> valueList = new ArrayList<>();
        for (int i = 0; i < columns.length; ++i) {
            if (this.categoryName.contains(i)) {
                valueList.add(this.categoryMap.get(i));
            } else valueList.add(Arrays.asList("-"));
        }
        System.out.println("categorized attributions: " + this.categoryName);
        List<List<String>> returnList = new ArrayList<>();
        descartesRecursive(valueList, 0, returnList, new ArrayList<String>());
        for (List<String> patternTuple : returnList) {
            //System.out.println(patternTuple);
            List<Integer> indexList = createIndex(patternTuple);
            //System.out.println(indexList.size());
            if ((double) indexList.size() / this.lineCount >= k) {
                System.out.println(patternTuple);
                inputList.add(createSubParsedColumns(indexList, patternTuple));
            }
        }
        return inputList;
    }

    //FP-growth
    public List<Input> getInput() throws InputIterationException {
        List<Input> inputList = new ArrayList<>();
        System.out.println("categorized attributions: " + this.categoryName);
        for (List<String> patternTuple : this.pattenTuples) {
            //System.out.println(patternTuple);
            List<Integer> indexList = createIndex(patternTuple);
            inputList.add(createSubParsedColumns(indexList, patternTuple));
        }
        return inputList;
    }

    public int[][] getInts() {
        final int COLUMN_COUNT = parsedColumns.size();
        final int ROW_COUNT = getLineCount();

        long time = System.currentTimeMillis();
        int[][] input2s = new int[ROW_COUNT][COLUMN_COUNT];
        IndexProvider<String> providerS = new IndexProvider<>();
        IndexProvider<Long> providerL = new IndexProvider<>();
        IndexProvider<Double> providerD = new IndexProvider<>();
        for (int col = 0; col < COLUMN_COUNT; ++col) {

            if (parsedColumns.get(col).getType() == String.class) {
                for (int line = 0; line < ROW_COUNT; ++line) {
                    input2s[line][col] = providerS.getIndex((String) parsedColumns.get(col).getValue(line)).intValue();
                }
            } else if (parsedColumns.get(col).getType() == Double.class) {
                for (int line = 0; line < ROW_COUNT; ++line) {
                    input2s[line][col] = providerD.getIndex((Double) parsedColumns.get(col).getValue(line)).intValue();

                }
            } else if (parsedColumns.get(col).getType() == Long.class) {
                for (int line = 0; line < ROW_COUNT; ++line) {
                    input2s[line][col] = providerL.getIndex((Long) parsedColumns.get(col).getValue(line)).intValue();
                }
            } else {
                log.error("Wrong type! " + parsedColumns.get(col).getValue(0).getClass().getName());
            }
        }
        providerS = IndexProvider.getSorted(providerS);
        providerL = IndexProvider.getSorted(providerL);
        providerD = IndexProvider.getSorted(providerD);
        for (int col = 0; col < COLUMN_COUNT; ++col) {
            if (parsedColumns.get(col).getType() == String.class) {
                for (int line = 0; line < ROW_COUNT; ++line) {
                    input2s[line][col] = providerS.getIndex((String) parsedColumns.get(col).getValue(line)).intValue();
                }
            } else if (parsedColumns.get(col).getType() == Double.class) {
                for (int line = 0; line < ROW_COUNT; ++line) {
                    input2s[line][col] = providerD.getIndex((Double) parsedColumns.get(col).getValue(line)).intValue();

                }
            } else if (parsedColumns.get(col).getType() == Long.class) {
                for (int line = 0; line < ROW_COUNT; ++line) {
                    input2s[line][col] = providerL.getIndex((Long) parsedColumns.get(col).getValue(line)).intValue();
                }
            } else {
                log.error("Wrong type!");
            }
        }

        log.info("rebuild: " + (System.currentTimeMillis() - time));
        return input2s;
    }

    private static Logger log = LoggerFactory.getLogger(Input.class);

}
