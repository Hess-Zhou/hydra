package de.hpi.naumann.dc.algorithms.hybrid.predicates;

public interface PartitionRefiner {
	public boolean satisfies(int line1, int lin2);
}
