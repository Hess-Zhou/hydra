package exp;

import config.Config;
import mocks.MetanomeMock;

public class Main {

    public static void main(String[] args) {
        Config conf = new Config(Config.Algorithm.HYDRA, Config.Dataset.TAX);
        MetanomeMock.execute(conf);
    }

}
