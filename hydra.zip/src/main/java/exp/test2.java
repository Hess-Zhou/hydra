package exp;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class ThreadA implements Callable<Integer> {

    @Override
    public Integer call() throws Exception {
        // 读取文件1
        Thread.sleep(10L);
        // 处理1的数据
        Thread.sleep(1L);
        return 1;
    }

}

class ThreadB implements Callable<Integer> {

    @Override
    public Integer call() throws Exception {
        // 读取文件2
        Thread.sleep(10L);
        // 处理2的数据
        Thread.sleep(1L);
        return 1;
    }

}

class ThreadC implements Callable<Integer> {

    @Override
    public Integer call() throws Exception {
        // 读取文件2
        Thread.sleep(10L);
        // 处理2的数据
        Thread.sleep(1L);
        return 1;
    }

}

public class test2 {

    /**
     * @param args
     * @throws InterruptedException
     * @throws ExecutionException
     */
    public static void main(String[] args) throws InterruptedException, ExecutionException {

        long start = System.currentTimeMillis();
        ExecutorService exec = Executors.newCachedThreadPool();
        Future<Integer> f = exec.submit(new ThreadA());
        Future<Integer> g = exec.submit(new ThreadB());
        Future<Integer> h = exec.submit(new ThreadC());

        int result = f.get() + g.get() + h.get();
        exec.shutdown();
        long end = System.currentTimeMillis();
        System.out.println("Run Time:");
        System.out.println(end - start);
    }

}