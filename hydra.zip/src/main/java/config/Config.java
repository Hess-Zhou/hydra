package config;

import java.io.File;

public class Config {

    public enum Algorithm {
        MYODDETECTOR, HYDRA
    }

    public enum Dataset {
        PLANETS, HOSPITOL, SPSTOCK, TAX, IRIS, DB_30, DB_12, DB_13, NCV_15, FLI_14, FLI_17,ATOM_11,ATOM_24
    }

    public Algorithm algorithm;
    public Dataset dataset;

    public String someStringParameter = "MyStringParamaterValue";
    public Integer someIntegerParameter = Integer.valueOf(42);
    public Boolean someBooleanParameter = Boolean.valueOf(true);

    public String inputDatasetName;
    //public String inputFolderPath = "data" + File.separator;
    public String inputFolderPath = "E:\\metanome-algorithms-master\\hydra\\data\\";
    public String inputFileEnding = ".csv";
    public String inputFileNullString = "";
    public char inputFileSeparator;
    public char inputFileQuotechar = '\"';
    public char inputFileEscape = '\\';
    public int inputFileSkipLines = 0;
    public boolean inputFileStrictQuotes = false;
    public boolean inputFileIgnoreLeadingWhiteSpace = true;
    public boolean inputFileHasHeader;
    public boolean inputFileSkipDifferingLines = true; // Skip lines that differ from the dataset's schema

    public String measurementsFolderPath = "io" + File.separator + "measurements" + File.separator;

    public String statisticsFileName = "statistics.txt";
    public String resultFileName = "results.txt";

    public boolean writeResults = true;

    public static Config create(String[] args) {
        if (args.length == 0)
            return new Config();

        Algorithm algorithm = null;
        String algorithmArg = args[0].toLowerCase();
        for (Algorithm possibleAlgorithm : Algorithm.values())
            if (possibleAlgorithm.name().toLowerCase().equals(algorithmArg))
                algorithm = possibleAlgorithm;

        Dataset dataset = null;
        String datasetArg = args[1].toLowerCase();
        for (Dataset possibleDataset : Dataset.values())
            if (possibleDataset.name().toLowerCase().equals(datasetArg))
                dataset = possibleDataset;

        if ((algorithm == null) || (dataset == null))
            wrongArguments();

        return new Config(algorithm, dataset);
    }

    private static void wrongArguments() {
        StringBuilder message = new StringBuilder();
        message.append("\r\nArguments not supported!");
        message.append("\r\nProvide correct values: <algorithm> <dataset>");
        throw new RuntimeException(message.toString());
    }

    public Config() {
        this(Algorithm.HYDRA, Dataset.PLANETS);
    }

    public Config(Algorithm algorithm, Dataset dataset) {
        this.algorithm = algorithm;
        this.setDataset(dataset);
    }

    @Override
    public String toString() {
        return "Config:\r\n\t" +
                "algorithm: " + this.algorithm.name() + "\r\n\t" +
                "dataset: " + this.inputDatasetName + this.inputFileEnding;
    }

    private void setDataset(Dataset dataset) {
        this.dataset = dataset;
        switch (dataset) {
            case HOSPITOL:
                this.inputDatasetName = "Hospital";
                this.inputFileSeparator = ',';
                this.inputFileHasHeader = true;
                break;
            case SPSTOCK:
                this.inputDatasetName = "SPStock";
                this.inputFileSeparator = ',';
                this.inputFileHasHeader = true;
                break;
            case TAX:
                this.inputDatasetName = "Tax";
                this.inputFileSeparator = ',';
                this.inputFileHasHeader = true;
                break;
            case DB_30:
                this.inputDatasetName = "DB 30";
                this.inputFileSeparator = ',';
                this.inputFileHasHeader = true;
                break;
            case DB_12:
                this.inputDatasetName = "DB 12";
                this.inputFileSeparator = ',';
                this.inputFileHasHeader = true;
                break;
            case DB_13:
                this.inputDatasetName = "DB 13";
                this.inputFileSeparator = ',';
                this.inputFileHasHeader = true;
                break;
            case NCV_15:
                this.inputDatasetName = "NCV 15";
                this.inputFileSeparator = ',';
                this.inputFileHasHeader = true;
                break;
            case FLI_14:
                this.inputDatasetName = "FLI 14";
                this.inputFileSeparator = ',';
                this.inputFileHasHeader = true;
                break;
            case FLI_17:
                this.inputDatasetName = "FLI 17";
                this.inputFileSeparator = ',';
                this.inputFileHasHeader = true;
                break;
            case ATOM_11:
                this.inputDatasetName = "Atom 11";
                this.inputFileSeparator = ',';
                this.inputFileHasHeader = true;
                break;
            case ATOM_24:
                this.inputDatasetName = "Atom 24";
                this.inputFileSeparator = ',';
                this.inputFileHasHeader = true;
                break;
        }
    }
}
